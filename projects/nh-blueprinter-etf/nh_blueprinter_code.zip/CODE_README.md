# code/ 폴더 안내

이 폴더의 코드를 실행하려면:

1. `requirements.txt`의 패키지를 설치합니다.
2. 원본 데이터를 각 스크립트와 같은 위치의 `./data/` 폴더에 넣어야 합니다.
   - `eda_merge_data_.py`, `blueprinter_종합경제점수.py`: NH 빅데이터 분석대회 제공 데이터(비공개) 및 GDELT export 데이터(https://www.gdeltproject.org)
   - `buy_recommend.py`, `sell_recommend.py`, `daily_recommend.py`: 위 스크립트들의 결과 CSV
3. Azure OpenAI API 키가 필요한 스크립트(`buy_recommend.py`, `sell_recommend.py`, `daily_recommend.py`)는 보안을 위해 코드에 키를 직접 넣지 않고 환경변수로 불러옵니다.

```bash
export AZURE_OPENAI_API_KEY="발급받은_키"   # Windows: set AZURE_OPENAI_API_KEY=발급받은_키
python buy_recommend.py
```

## 파일 설명
| 파일 | 역할 | 담당 |
|---|---|---|
| `eda_merge_data_.py` | NH 제공 8개 데이터 병합 + 상관분석·시각화(EDA) | 조용성 |
| `blueprinter_종합경제점수.py` | GDELT 뉴스 데이터 DBSCAN 섹터 클러스터링 + 종합경제점수 산출 | 조용성 |
| `buy_recommend.py` | 매수 추천 — 고객 클러스터링 + Azure 챗봇 추천 멘트 생성 | 팀 공동 (Azure 연동: 동료) |
| `sell_recommend.py` | 매도 추천 — 종합경제점수 기준 매도 판단 + 챗봇 멘트 생성 | 팀 공동 (Azure 연동: 동료) |
| `daily_recommend.py` | 오늘의 주목/위험 섹터 안내 챗봇 멘트 생성 | 팀 공동 (Azure 연동: 동료) |

원본 API 키가 포함되어 있던 부분은 모두 환경변수 참조로 교체했고, 로컬 절대경로는 상대경로(`./data/`)로 정리했습니다.
