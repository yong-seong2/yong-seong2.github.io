import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
import requests
import os

# Configuration
# ※ 보안을 위해 API 키는 코드에 직접 작성하지 않고 환경변수에서 불러옵니다.
#   실행 전 터미널에서: export AZURE_OPENAI_API_KEY="발급받은_키"  (Windows: set AZURE_OPENAI_API_KEY=발급받은_키)
API_KEY = os.environ.get("AZURE_OPENAI_API_KEY", "")
ENDPOINT = "https://blueprinter.openai.azure.com/openai/deployments/etf_recommendation_bot/chat/completions?api-version=2024-02-15-preview"

if not API_KEY:
    raise SystemExit("환경변수 AZURE_OPENAI_API_KEY가 설정되지 않았습니다.")


# Load Data
csv_path = "./data/Merged_Sector_Summary_Data__August_26_.csv"
try:
    data = pd.read_csv(csv_path)
    print(f"Loaded {len(data)} rows from CSV.")
except FileNotFoundError:
    raise SystemExit("CSV 파일을 찾을 수 없습니다. 파일 경로를 확인하세요.")


# 사용자 입력 함수
def get_user_input():
    print("사용자 투자 정보를 입력하세요:")
    age_group = int(input("나이대 (20대: 1, 30대: 2, 40대: 3, 50대: 4, 60대 이상: 5): "))
    asset_group = int(input("자산규모 (3천만 원 미만: 1, 1억 미만: 2, 1억 이상: 3): "))
    skill_level = int(input("숙련도 (초보: 1, 중급: 2, 고급: 3): "))
    risk_preference = input("투자 성향 (안정형 / 위험형): ").strip()
    return age_group, asset_group, skill_level, risk_preference.lower()

# 중분류 코드 매핑
def get_customer_code(age_group, asset_group, skill_level):
    customer_code_age = {1: 21, 2: 22, 3: 23, 4: 24, 5: 25}[age_group]
    customer_code_asset = {1: 31, 2: 32, 3: 33}[asset_group]
    customer_code_skill = {1: 11, 2: 12, 3: 13}[skill_level]
    return [customer_code_age, customer_code_asset, customer_code_skill]

# 사용자 입력 및 중분류 코드 매핑
age_group, asset_group, skill_level, risk_preference = get_user_input()
customer_codes = get_customer_code(age_group, asset_group, skill_level)

# 중분류 코드로 데이터 필터링
filtered_data = data[data["고객구성중분류코드"].isin(customer_codes)].copy()
if filtered_data.empty:
    raise SystemExit("해당 조건에 맞는 데이터가 없습니다. 입력값을 다시 확인하세요.")

# 주요 투자 지표 선택 및 정규화
features = ["변동성 z값", "sharpe 비율 z값", "평균_종합경제점수"]
scaler = StandardScaler()
scaled_data = scaler.fit_transform(filtered_data[features])

# 클러스터링: 중분류 코드 기준
kmeans = KMeans(n_clusters=len(customer_codes), random_state=42, n_init=10)
filtered_data.loc[:, "Cluster"] = kmeans.fit_predict(scaled_data)

# 추천 ETF: 동일 클러스터에서 상위 3개 이상 반환
user_vector = pd.DataFrame([[0.3, 1.2, 0.8]], columns=features)
user_vector_scaled = scaler.transform(user_vector)
user_cluster = kmeans.predict(user_vector_scaled)[0]

# 정렬 기준 설정
if risk_preference == "안정형":
    recommended_etfs = filtered_data[filtered_data["Cluster"] == user_cluster].sort_values(
        by=["sharpe 비율 z값", "변동성 z값", "평균_종합경제점수"], ascending=[False, True, False]
    )
elif risk_preference == "위험형":
    recommended_etfs = filtered_data[filtered_data["Cluster"] == user_cluster].sort_values(
        by=["변동성 z값", "평균_종합경제점수"], ascending=[False, False]
    )
else:
    raise ValueError("올바른 투자 성향(안정형/위험형)을 입력하세요.")

# 최소 3개 ETF 반환
recommended_etfs = recommended_etfs.head(3)
if len(recommended_etfs) < 3:
    print("추천 가능한 ETF가 3개 미만입니다. 조건을 재조정하세요.")
    raise SystemExit()

# OpenAI API 호출을 위한 프롬프트 생성
etf_info = recommended_etfs[["대상ETF티커", "Sector", "sharpe 비율 z값", "변동성 z값", "평균_종합경제점수"]].to_string(index=False)
prompt = f"""
사용자의 투자 성향과 분석된 클러스터 정보를 바탕으로 추천된 ETF는 다음과 같습니다:

{etf_info}

당신은 투자 전문가이고, 사용자는 증권사의 고객입니다.
사용자는 투자에 대한 정보가 많이 없는 상황이고 당신에게 조언을 구하고자 합니다.

먼저 중복되지 않고, 매수하길 추천하는 상품 3개에 대해 나열하고 뒤에 이유에 대해 설명해주세요
각 ETF를 추천한 이유를 사용자 친화적인 설명과 테이블로 작성해주세요.


"""


# OpenAI API Call
headers = {
    "Content-Type": "application/json",
    "api-key": API_KEY,
}
payload = {
    "messages": [
        {"role": "system", "content": prompt},
        {"role": "user", "content": "ETF 추천 이유를 설명해주세요."}
    ],
    "temperature": 0.7,
    "top_p": 0.5,
    "max_tokens": 500,
}
try:
    response = requests.post(ENDPOINT, headers=headers, json=payload)
    response.raise_for_status()
    result = response.json()
    print("GPT의 추천 이유:")
    print(result["choices"][0]["message"]["content"])
except requests.RequestException as e:
    print(f"API 호출 실패: {e}")
