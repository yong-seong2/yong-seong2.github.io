import pandas as pd
import requests
import os

# Configuration
# ※ 보안을 위해 API 키는 코드에 직접 작성하지 않고 환경변수에서 불러옵니다.
#   실행 전 터미널에서: export AZURE_OPENAI_API_KEY="발급받은_키"  (Windows: set AZURE_OPENAI_API_KEY=발급받은_키)
API_KEY = os.environ.get("AZURE_OPENAI_API_KEY", "")

ENDPOINT = "https://blueprinter.openai.azure.com/openai/deployments/etf_recommendation_bot/chat/completions?api-version=2024-02-15-preview"

# Load Data
def load_data(csv_path):
    try:
        data = pd.read_csv(csv_path)
        print(f"Loaded {len(data)} rows from CSV.")
        return data
    except FileNotFoundError:
        raise SystemExit("CSV 파일을 찾을 수 없습니다. 파일 경로를 확인하세요.")

# Filter Data by Date
def filter_data_by_date(data, date):
    filtered_data = data[data["일자"] == date]
    if filtered_data.empty:
        raise ValueError(f"{date}에 대한 데이터가 없습니다.")
    return filtered_data

# Calculate Top Sectors
def calculate_top_sectors(filtered_data, n=3):
    # 오늘의 주목할 분야
    focus_sectors = filtered_data[filtered_data["평균_종합경제점수"] > 0]
    focus_sectors = focus_sectors.sort_values(by="평균_종합경제점수", ascending=False).head(n)

    # 오늘의 위험 분야
    risky_sectors = filtered_data[filtered_data["평균_종합경제점수"] < 0]
    risky_sectors = risky_sectors.sort_values(by="평균_종합경제점수").head(n)

    return focus_sectors[["Sector", "평균_종합경제점수"]], risky_sectors[["Sector", "평균_종합경제점수"]]

# Generate Prompt for OpenAI
def generate_sector_prompt(focus_sectors, risky_sectors):
    # 오늘의 주목할 분야 섹터 정보 생성
    focus_info = "\n".join([
        f"{i+1}. {row['Sector']}, 점수: {row['평균_종합경제점수']:.2f}"
        for i, row in focus_sectors.iterrows()
    ])

    # 오늘의 위험 분야 섹터 정보 생성
    risky_info = "\n".join([
        f"{i+1}. {row['Sector']}, 점수: {row['평균_종합경제점수']:.2f}"
        for i, row in risky_sectors.iterrows()
    ])

    # 프롬프트 생성
    prompt = f"""
    
당신은 투자 전문가이고, 사용자는 증권사의 고객입니다.
사용자는 투자에 대한 정보가 많이 없는 상황이고 당신에게 조언을 구하고자 합니다.

아래 데이터를 바탕으로 오늘의 주목할 분야와 오늘의 위험 분야를 제시하고 이유를 설명하세요.

### 데이터:
오늘의 주목할 분야:
{focus_info}

오늘의 위험 분야:
{risky_info}

### 결과 형식:
오늘의 주목할 분야:
1. 섹터: [섹터 이름], 이유: [이유]
2. 섹터: [섹터 이름], 이유: [이유]
...

오늘의 위험 분야:
1. 섹터: [섹터 이름], 이유: [이유]
2. 섹터: [섹터 이름], 이유: [이유]
...
"""
    return prompt

# Call OpenAI API
def call_openai_api(prompt):
    if not API_KEY:
        print("환경변수 AZURE_OPENAI_API_KEY가 설정되지 않았습니다.")
        return None
    headers = {
        "Content-Type": "application/json",
        "api-key": API_KEY,
    }
    payload = {
        "messages": [
            {"role": "system", "content": prompt},
            {"role": "user", "content": "오늘의 주목할 분야와 위험 분야를 설명해주세요."}
        ],
        "temperature": 0.7,
        "max_tokens": 500,
    }
    
    try:
        response = requests.post(ENDPOINT, headers=headers, json=payload)
        response.raise_for_status()
        return response.json()["choices"][0]["message"]["content"]
    except requests.RequestException as e:
        print(f"API 호출 실패: {e}")
        return None

# Main Execution
if __name__ == "__main__":
    # Load Data
    csv_path = "./data/sector_summary_all_dates.csv"
    data = load_data(csv_path)

    # Filter Data for Target Date
    target_date = "2024-08-26"
    try:
        filtered_data = filter_data_by_date(data, target_date)

        # Calculate Top Sectors
        focus_sectors, risky_sectors = calculate_top_sectors(filtered_data, n=3)

        # Generate Prompt
        prompt = generate_sector_prompt(focus_sectors, risky_sectors)

        # Call OpenAI API
        response = call_openai_api(prompt)

        if response:
            print("\nOpenAI API 응답:")
            print(response)
        else:
            print("API 호출 실패")
    except ValueError as e:
        print(f"Error: {e}")
