import pandas as pd
import requests
import os

# Configuration
# ※ 보안을 위해 API 키는 코드에 직접 작성하지 않고 환경변수에서 불러옵니다.
#   실행 전 터미널에서: export AZURE_OPENAI_API_KEY="발급받은_키"  (Windows: set AZURE_OPENAI_API_KEY=발급받은_키)
API_KEY = os.environ.get("AZURE_OPENAI_API_KEY", "")
ENDPOINT = "https://blueprinter.openai.azure.com/openai/deployments/etf_recommendation_bot/chat/completions?api-version=2024-02-15-preview"

# Load Data
csv_path = "./data/Merged_Sector_Summary_Data__August_26_.csv"
data = pd.read_csv(csv_path)

# 사용자 입력
def get_user_input():
    etf_list = input("현재 보유 ETF 리스트 (쉼표로 구분): ").strip().split(",")
    risk_preference = input("투자 성향 (안정형/위험형): ").strip()
    return etf_list, risk_preference

# OpenAI 프롬프트 생성
def generate_prompt(etf_list, risk_preference, data):
    etf_data = []
    for etf in etf_list:
        etf_row = data[data["대상ETF티커"] == etf.strip()]
        if not etf_row.empty:
            etf_data.append({
                "ETF 이름": etf.strip(),
                "섹터": etf_row["Sector"].iloc[0],
                "평균_종합경제점수": etf_row["평균_종합경제점수"].iloc[0],
            })

    etf_info = "\n".join([
        f"{i+1}. ETF 이름: {row['ETF 이름']}, 섹터: {row['섹터']}, 평균_종합경제점수: {row['평균_종합경제점수']}"
        for i, row in enumerate(etf_data)
    ])
    
    prompt = f"""
당신은 투자 전문가이고, 사용자는 증권사의 고객입니다.
사용자는 투자에 대한 정보가 많이 없는 상황이고 당신에게 조언을 구하고자 합니다.

아래 데이터와 사용자 정보를 바탕으로 ETF별로 매도/매수 우선순위를 결정하세요.

ETF 데이터를 개별적으로 평가하여 매수/매도 여부를 판단하세요.

### 사용자 정보:
- 투자 성향: {risk_preference}
- 현재 보유 ETF 리스트: {', '.join(etf_list)}

### ETF 데이터:
{etf_info}

### 기준:
- 안정형:
  - 평균_종합경제점수 > 0.5 → 매수 추천
  - 평균_종합경제점수 < -0.5 → 매도 추천
  - 그 외 → 유지
- 위험형:
  - 평균_종합경제점수 > 1.5 → 매수 추천
  - 평균_종합경제점수 < -1.5 → 매도 추천
  - 그 외 → 유지

### 결과 형식:
1. ETF 이름: [ETF 이름], 섹터: [섹터], 점수: [점수], 추천: [추천]
2. ETF 이름: [ETF 이름], 섹터: [섹터], 점수: [점수], 추천: [추천]
-  ETF별로 독립적으로 평가한 결과를 제공하세요.
-  사용자가 보유하는 ETF 수 만큼 위의 결과형식을 출력하세요
"""
    return prompt


# OpenAI API 호출
def call_openai_api(prompt):
    if not API_KEY:
        print("환경변수 AZURE_OPENAI_API_KEY가 설정되지 않았습니다.")
        return None
    headers = {
        "Content-Type": "application/json",
        "api-key": API_KEY,
    }
    payload = {
        "messages": [
            {"role": "system", "content": prompt},
            {"role": "user", "content": "매수/매도 추천을 알려주세요."}
        ],
        "temperature": 0.7,
        "top_p": 0.5,
        "max_tokens": 500,
    }

    try:
        response = requests.post(ENDPOINT, headers=headers, json=payload)
        response.raise_for_status()
        result = response.json()
        return result["choices"][0]["message"]["content"]
    except requests.RequestException as e:
        print(f"API 호출 실패: {e}")
        return None

# 메인 실행 흐름
etf_list, risk_preference = get_user_input()
prompt = generate_prompt(etf_list, risk_preference, data)
response = call_openai_api(prompt)

if response:
    print("\n추천 결과:")
    print(response)

