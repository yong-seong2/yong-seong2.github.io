import os
import sys
import time
import queue
from datetime import datetime
from pathlib import Path

import numpy as np
import sounddevice as sd
import soundfile as sf

# 같은 폴더에 있는 STT_time.py, TTS_time.py를 쓰기 위해 경로 추가
BASE_DIR = Path(__file__).resolve().parent
sys.path.append(str(BASE_DIR))

from STT_time import stt           # Whisper STT (파일 → 텍스트)
from TTS_time import tts as zonos_tts  # Zonos TTS 함수


# -------------------------------------------------------------
# 공통 설정
# -------------------------------------------------------------
SAMPLE_RATE = 16_000   # Whisper랑 맞추기
CHANNELS = 1           # 모노 입력
DEFAULT_OUT_DIR = BASE_DIR / "records"
DEFAULT_OUT_DIR.mkdir(exist_ok=True)

# 무음 감지 관련
BLOCK_DURATION = 0.3     # 초 단위, 한 번에 처리할 블록 길이
SILENCE_THRESHOLD = 0.01 # RMS 기준 (작을수록 민감)
SILENCE_DURATION = 1.5   # 몇 초 이상 조용하면 "끝났다"로 볼지


# -------------------------------------------------------------
# 유틸: 파일 이름 만들기
# -------------------------------------------------------------
def make_wav_path(prefix="record"):
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    return DEFAULT_OUT_DIR / f"{prefix}_{ts}.wav"


# -------------------------------------------------------------
# 기능 1: 조작(Enter) 이후, 무음 나오면 자동 종료 녹음
# -------------------------------------------------------------
def record_until_silence(
    outfile: str | Path | None = None,
    samplerate: int = SAMPLE_RATE,
    channels: int = CHANNELS,
    block_duration: float = BLOCK_DURATION,
    silence_threshold: float = SILENCE_THRESHOLD,
    silence_duration: float = SILENCE_DURATION,
) -> Path:
    """
    사용자가 Enter를 눌러 시작하면,
    - 사람이 말하기 시작할 때까지 기다렸다가
    - 말하는 동안 녹음하고
    - 지정된 시간만큼 조용해지면 종료하는 함수
    """

    if outfile is None:
        outfile = make_wav_path("utterance")
    outfile = Path(outfile)

    print("\n[REC] 🎙 녹음을 시작합니다.")
    print("     말을 시작하면 자동으로 녹음이 진행되고,")
    print(f"     약 {silence_duration}초 이상 조용하면 자동으로 종료됩니다.")
    print("     (Ctrl + C 를 누르면 강제 종료)\n")

    q = queue.Queue()

    def callback(indata, frames, time_info, status):
        if status:
            print(f"[REC] ⚠️ Status: {status}", flush=True)
        q.put(indata.copy())

    blocksize = int(samplerate * block_duration)
    max_silence_blocks = int(silence_duration / block_duration)

    audio_chunks = []
    started_talking = False
    silence_blocks = 0

    with sd.InputStream(
        samplerate=samplerate,
        channels=channels,
        dtype="float32",
        blocksize=blocksize,
        callback=callback,
    ):
        print("[REC] 이제 말을 시작해도 됩니다.\n")
        try:
            while True:
                block = q.get()
                # (frames, channels)
                rms = np.sqrt(np.mean(block ** 2))

                if not started_talking:
                    # 아직 말 안 한 상태 → 소리가 일정 이상 나면 "말 시작"으로 간주
                    if rms > silence_threshold:
                        started_talking = True
                        print("[REC] ✅ 음성 감지! 녹음을 시작합니다.")
                        audio_chunks.append(block)
                    # 계속 조용하면 그냥 대기
                    continue

                # 이미 말 시작한 상태
                audio_chunks.append(block)

                if rms < silence_threshold:
                    silence_blocks += 1
                else:
                    silence_blocks = 0

                # 일정 시간 이상 연속으로 조용 → 종료
                if silence_blocks >= max_silence_blocks:
                    print(f"[REC] ⏹ 무음 {silence_duration}초 이상 감지 → 녹음 종료.")
                    break

        except KeyboardInterrupt:
            print("\n[REC] ⛔ 사용자가 녹음을 중단했습니다.")
        finally:
            sd.stop()

    if not audio_chunks:
        print("[REC] ⚠️ 녹음된 내용이 없습니다. 파일을 저장하지 않습니다.")
        return outfile

    audio = np.concatenate(audio_chunks, axis=0)

    # (frames,) 또는 (frames, 1) 형태로 저장
    sf.write(outfile, audio, samplerate)
    print(f"[REC] 💾 WAV 파일로 저장 완료: {outfile}\n")

    return outfile


# -------------------------------------------------------------
# 기능 2: “제트야~” 호출 → “응! 무슨일이야?” TTS → 그때부터 녹음
# -------------------------------------------------------------
def wait_for_wake_word_and_record(
    voice_file_path: str,
    embedding_path: str = "캐릭터_embedding.pt",
    wake_words: tuple[str, ...] = ("제트야", "제트야~", "제트"),
    listen_chunk_sec: float = 2.5,
) -> Path | None:
    """
    1) 마이크로 짧은 구간씩 계속 녹음하면서 Whisper STT로 텍스트를 검사.
    2) 텍스트 안에 wake_words 중 하나가 들어가면:
       - Zonos TTS로 "응! 무슨일이야?" 재생
       - TTS 재생이 끝난 뒤, record_until_silence()로 실제 발화 녹음
    """
    print("\n[Wake] 👂 '제트야~' 라는 호출을 기다리는 중입니다... (Ctrl + C 로 종료)")
    tmp_wav = BASE_DIR / "wake_tmp.wav"

    try:
        while True:
            # 1) wake word 감지를 위한 짧은 녹음
            frames = int(listen_chunk_sec * SAMPLE_RATE)
            audio = sd.rec(frames, samplerate=SAMPLE_RATE,
                           channels=CHANNELS, dtype="float32")
            sd.wait()

            sf.write(tmp_wav, audio, SAMPLE_RATE)

            # 2) STT로 텍스트 추출
            try:
                text = stt(str(tmp_wav))
            except Exception as e:
                print(f"[Wake] STT 중 오류 발생: {e}")
                continue

            norm_text = text.replace(" ", "")
            print(f"[Wake] 인식된 텍스트: {text}")

            if any(w in norm_text for w in wake_words):
                print("[Wake] ✅ '제트야' 호출을 감지했습니다!")
                break

        # 3) 호출에 대한 TTS 응답
        reply_text = "응! 무슨일이야?"
        print(f"[Wake] TTS 응답 생성: {reply_text}")

        tts_out_path = BASE_DIR / "wake_reply.wav"
        try:
            out_path = zonos_tts(
                text=reply_text,
                voice_file_path=voice_file_path,
                embedding_path=embedding_path,
                output_path=str(tts_out_path),
            )
        except Exception as e:
            print(f"[Wake] TTS 생성 중 오류 발생: {e}")
            out_path = None

        # 4) 생성된 음성을 재생
        if out_path and Path(out_path).exists():
            print("[Wake] 🎧 TTS 음성을 재생합니다.")
            data, sr = sf.read(out_path, dtype="float32")
            sd.play(data, sr)
            sd.wait()
        else:
            print("[Wake] ⚠️ 재생할 TTS 파일이 없습니다.")

        # 5) 이제 실제 유저 발화 녹음 시작
        input("\n[Wake] 이제 말할 내용을 준비해 주세요. 준비되면 Enter 를 눌러 녹음을 시작합니다.")
        recorded_path = record_until_silence()

        return recorded_path

    except KeyboardInterrupt:
        print("\n[Wake] ⛔ 사용자가 대기 상태를 종료했습니다.")
        return None
    finally:
        if tmp_wav.exists():
            tmp_wav.unlink(missing_ok=True)


# -------------------------------------------------------------
# 메인 진입점: 모드 선택
# -------------------------------------------------------------
if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="마이크 녹음 & 제트야 웨이크워드 테스트용 스크립트")
    parser.add_argument(
        "--mode",
        choices=["simple", "wake"],
        default="simple",
        help="simple: Enter 후 녹음 시작 / wake: '제트야' 호출을 기다렸다가 TTS 응답 후 녹음",
    )
    parser.add_argument(
        "--voice",
        type=str,
        default=None,
        help="Zonos TTS용 화자 음성 파일 경로 (wake 모드에서 필수)",
    )
    parser.add_argument(
        "--embedding",
        type=str,
        default="캐릭터_embedding.pt",
        help="Zonos 화자 임베딩 파일 경로",
    )

    args = parser.parse_args()

    if args.mode == "simple":
        input("[MAIN] Enter 를 누르면 녹음을 시작합니다...")
        out = record_until_silence()
        print(f"[MAIN] ✅ 최종 녹음 파일: {out}")

    elif args.mode == "wake":
        if args.voice is None:
            print("[MAIN] ⚠️ wake 모드에서는 --voice <화자_음성.wav> 를 지정해야 합니다.")
            sys.exit(1)

        out = wait_for_wake_word_and_record(
            voice_file_path=args.voice,
            embedding_path=args.embedding,
        )
        print(f"[MAIN] ✅ 최종 녹음 파일: {out}")

