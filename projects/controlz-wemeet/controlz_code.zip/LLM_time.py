# LLM_time.py
import os
import ctypes
import sys
import time
import torch
from transformers import AutoTokenizer, AutoModelForCausalLM, BitsAndBytesConfig

# ---------------------------------------------------------
# ✅ [CRITICAL FIX] DGX/Blackwell Library Loader (Complete)
# ---------------------------------------------------------

# 1. bitsandbytes Version Spoofing
os.environ["BNB_CUDA_VERSION"] = "129"

# 2. Grace Blackwell / GB10 Compatibility
os.environ["TRITON_PTXAS_PATH"] = "/usr/local/cuda/bin/ptxas"
os.environ["TORCH_CUDA_ARCH_LIST"] = "9.0"

# 3. Generic Library Loader Function
def force_load_library(module_name, lib_filename):
    """
    pip로 설치된 nvidia 패키지 내부나 시스템 경로에서 라이브러리를 찾아 강제 로드합니다.
    """
    candidates = []

    # [방법 1] nvidia 패키지 내부 탐색 (Import 방식)
    try:
        import importlib
        mod = importlib.import_module(module_name)
        
        # __file__이 없고 __path__만 있는 경우 (Namespace 패키지 대응)
        if hasattr(mod, "__path__"):
            for path in mod.__path__:
                candidates.append(os.path.join(path, lib_filename))
        
        # __file__이 있는 경우
        if hasattr(mod, "__file__") and mod.__file__:
            candidates.append(os.path.join(os.path.dirname(mod.__file__), lib_filename))
    except ImportError:
        pass

    # [방법 2] Conda 환경 경로 탐색 (수동 지정)
    conda_prefix = os.environ.get("CONDA_PREFIX")
    if conda_prefix:
        # pip 패키지 구조 (site-packages/nvidia/...)
        pkg_root = module_name.split('.')[0] # nvidia
        sub_dir = module_name.replace('.', os.sep) 
        candidates.append(os.path.join(conda_prefix, "lib", "python3.10", "site-packages", sub_dir, lib_filename))
        # conda 패키지 구조 (lib/...)
        candidates.append(os.path.join(conda_prefix, "lib", lib_filename))

    # [방법 3] 시스템 기본 경로
    candidates.extend([
        f"/usr/local/cuda/lib64/{lib_filename}",
        f"/usr/lib/x86_64-linux-gnu/{lib_filename}",
        f"/usr/lib/aarch64-linux-gnu/{lib_filename}"
    ])

    # 로드 시도
    for path in candidates:
        if os.path.exists(path):
            try:
                ctypes.CDLL(path, mode=ctypes.RTLD_GLOBAL)
                print(f"[LLM_Setup] ✅ 라이브러리 로드 성공: {lib_filename} -> {path}")
                return True
            except OSError:
                continue
    
    print(f"[LLM_Setup] ❌ ERROR: {lib_filename} 파일을 찾을 수 없습니다. pip install을 확인하세요.")
    return False

# ✅ 핵심 라이브러리 3대장 순차 로드
# 1. CUDA Runtime
force_load_library("nvidia.cuda_runtime.lib", "libcudart.so.12")
# 2. CUBLAS (행렬 연산)
force_load_library("nvidia.cublas.lib", "libcublas.so.12")
# 3. nvJitLink (JIT 링킹 - 이번 에러 해결)
force_load_library("nvidia.nvjitlink.lib", "libnvJitLink.so.12")

# ---------------------------------------------------------

# ---- 캐시 기본값을 /tmp로 강제 (env가 없을 때 안전하게) ----
def _ensure_hf_caches():
    base = os.getenv("HF_HOME") or "/tmp/hf_cache"
    os.environ.setdefault("HF_HOME", base)
    os.environ.setdefault("HUGGINGFACE_HUB_CACHE", os.path.join(base, "hub"))
    os.environ.setdefault("HF_HUB_CACHE", os.path.join(base, "hub"))
    os.environ.setdefault("TRANSFORMERS_CACHE", os.path.join(base, "transformers"))
    os.environ.setdefault("HF_DATASETS_CACHE", os.path.join(base, "datasets"))
    for p in [
        os.environ["HUGGINGFACE_HUB_CACHE"],
        os.environ["TRANSFORMERS_CACHE"],
        os.environ["HF_DATASETS_CACHE"],
    ]:
        os.makedirs(p, exist_ok=True)
    return os.environ["TRANSFORMERS_CACHE"]

CACHE_DIR = _ensure_hf_caches()
print(f"[LLM] cache_dir: {CACHE_DIR}")

MODEL_ID = os.getenv("EXAONE_MODEL_ID", "LGAI-EXAONE/EXAONE-3.5-2.4B-Instruct")
HF_TOKEN = os.getenv("HF_TOKEN", None)

bnb_cfg = BitsAndBytesConfig(
    load_in_4bit=True,
    bnb_4bit_compute_dtype=torch.bfloat16,
    bnb_4bit_use_double_quant=True,
    bnb_4bit_quant_type="nf4",
)

def _auth_kw():
    return {"token": HF_TOKEN} if HF_TOKEN else {}

print(f"[LLM] loading {MODEL_ID} (4bit)…")

tok = AutoTokenizer.from_pretrained(
    MODEL_ID,
    trust_remote_code=True,
    cache_dir=CACHE_DIR,
    **_auth_kw(),
)
if tok.pad_token is None and tok.eos_token is not None:
    tok.pad_token = tok.eos_token

model = AutoModelForCausalLM.from_pretrained(
    MODEL_ID,
    quantization_config=bnb_cfg,
    torch_dtype=torch.bfloat16,
    trust_remote_code=True,
    cache_dir=CACHE_DIR,
    **_auth_kw(),
).to("cuda").eval()

print("[LLM] ready.")

SYSTEM_PROMPT = (
    "-----------------------------------"
    "# 역할 (Persona)"
    "너는 5세에서 9세 사이의 아이와 이야기하는 ‘마음 단짝’이야."
    "언제나 아이의 편에 서서 따뜻하고 다정하게 들어주는 비밀 친구야."
    "아이의 말을 절대 판단하거나 비판하지 않고, 아이의 감정을 존중해."
    "# 핵심 목표 (Core Goal)"
    "아이의 감정과 하루를 편안하게 이야기하도록 돕고,"
    "대화를 통해 아이가 스스로 긍정적인 생각을 하도록 격려해."
    "# 대화 스타일 (Communication Style)"
    "1. **어투:** 부드럽고 따뜻한 말투. 감정에 공감하며 대답해."
    "2. **문장:** 5~9세 아이가 이해할 수 있게, 짧고 쉬운 문장만 써."
    "3. **단어:** 영어, 한자어, 어려운 말 절대 금지. 예쁜 순우리말 사용."
    "4. **질문법:** 부드럽게 어투로 묻기."
    "# 대화 원칙 (Core Tasks)"
    "1. **감정 탐색 (필수):** 아이의 현재 감정을 먼저 물어봐."
    "2. **이유 탐색 (필수):** 감정을 말하면 그 이유나 상황을 자연스럽게 물어봐."
    "3. **공감 + 격려:** 아이의 말에 먼저 공감하고, 짧은 격려나 따뜻한 말로 반응해."
    "4. **긍정적 행동 유도:** 문제 상황이 나오면 조언보다 ‘작은 제안’만."
    "5. **대화 유도:** 아이가 단답형으로 말해도, 구체적인 주제로 이어가기."
    "# 금지 및 안전 규칙 (Safety & Privacy Rules)"
    "1. 개인정보 (이름, 주소, 학교, 부모님 이름, 번호 등) 절대 묻지 마."
    "2. 의료·심리·법률 조언 금지 (‘병원 가봐’, ‘약 먹어’ 같은 말은 절대 금지)."
    "3. 위험 신호 감지 시 어른들에게 알리게끔 유도:"
    "# 출력 규칙"
    "1. 너의 답변에는 절대로 설명, 이유, 분석, 요약, breakdown을 포함하지 마."
    "2. 아이에게 실제로 말해도 되는 문장만 출력해."
    "3. 개발자에게 설명하듯 말하지 마."
    "4. 꼭 필요한 말만 해 너무 길게 말하지 말고"
)

def _model_name():
    try:
        return getattr(model.config, "_name_or_path", None) or MODEL_ID
    except Exception:
        return MODEL_ID

def build_prompt(user_text: str, emotion: str | None, history: list[dict] | None):
    emo = (emotion or "neutral").lower()
    hist = history or []
    lines = [f"System: {SYSTEM_PROMPT}"]
    for turn in hist[-6:]:
        lines.append(f"User: {turn.get('user','')}")
        lines.append(f"Assistant: {turn.get('assistant','')}")
    lines.append(f"User({emo}): {user_text}")
    lines.append("Assistant:")
    return "\n".join(lines)

@torch.inference_mode()
def generate_reply(
    user_text: str,
    emotion: str | None = None,
    history: list[dict] | None = None,
    max_new_tokens: int = 128,
    temperature: float = 0.4,
    top_p: float = 0.9,
) -> tuple[str, int, str]:
    prompt = build_prompt(user_text, emotion, history)
    inputs = tok(prompt, return_tensors="pt").to(model.device)

    t0 = time.time()
    out = model.generate(
        **inputs,
        max_new_tokens=max_new_tokens,
        do_sample=True,
        temperature=temperature,
        top_p=top_p,
        pad_token_id=tok.pad_token_id or tok.eos_token_id,
    )
    latency_ms = int((time.time() - t0) * 1000)

    text = tok.decode(out[0], skip_special_tokens=True)
    cut = text.rsplit("Assistant:", 1)
    reply = (cut[-1] if len(cut) > 1 else text).strip()

    return reply, latency_ms, _model_name()

@torch.inference_mode()
def generate_reply_streaming(
    user_text: str,
    emotion: str | None = None,
    history: list[dict] | None = None,
    max_new_tokens: int = 128,
    temperature: float = 0.4,
    top_p: float = 0.9,
):
    t0 = time.time()
    prompt = build_prompt(user_text, emotion, history)
    inputs = tok(prompt, return_tensors="pt").to(model.device)
    torch.cuda.synchronize()
    print(f"[LLM] ⏱ (1) Tokenization + GPU 이동: {time.time() - t0:.4f} seconds")

    t1 = time.time()
    output = model.generate(
        **inputs,
        max_new_tokens=max_new_tokens,
        do_sample=True,
        temperature=temperature,
        top_p=top_p,
        pad_token_id=tok.pad_token_id or tok.eos_token_id,
    )
    torch.cuda.synchronize()
    print(f"[LLM] ⏱ (2) 모델 generate: {time.time() - t1:.4f} seconds")

    t2 = time.time()
    full_text = tok.decode(output[0], skip_special_tokens=True)
    torch.cuda.synchronize()
    print(f"[LLM] ⏱ (3) 디코딩: {time.time() - t2:.4f} seconds")

    cut = full_text.rsplit("Assistant:", 1)
    assistant_reply = (cut[-1] if len(cut) > 1 else full_text).strip()

    print(f"[LLM] ✅ 총 LLM 처리 시간: {time.time() - t0:.4f} seconds\n")

    buffer = ""
    for chunk in assistant_reply.split(". "):
        sentence = (buffer + chunk).strip()
        if sentence:
            yield sentence + "."
            buffer = ""
    if buffer.strip():
        yield buffer.strip()
