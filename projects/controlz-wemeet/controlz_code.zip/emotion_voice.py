import torch
import torch.nn as nn
import librosa
import numpy as np

# -------------------------------------------------------
# 감정 클래스 정의
# -------------------------------------------------------
EMOTION_CLASSES = ["기쁨", "두려움", "슬픔", "없음", "화남"]


# -------------------------------------------------------
# 모델 정의 (학습 모델과 동일)
# -------------------------------------------------------

class AttentionGRU(nn.Module):
    def __init__(self, input_dim=40, hidden_dim=128, num_classes=5):
        super().__init__()
        self.gru = nn.GRU(input_dim, hidden_dim, batch_first=True, bidirectional=True)
        self.attn = nn.Linear(hidden_dim * 2, 1)
        self.fc = nn.Linear(hidden_dim * 2, num_classes)

    def forward(self, x, lengths):
        # x: (B, T, F), lengths: (B,)
        packed = nn.utils.rnn.pack_padded_sequence(
            x, lengths.cpu(), batch_first=True, enforce_sorted=False
        )
        out, _ = self.gru(packed)
        out, _ = nn.utils.rnn.pad_packed_sequence(out, batch_first=True)

        # 어텐션 가중치 계산
        attn_w = torch.softmax(self.attn(out).squeeze(-1), dim=1)  # (B, T)
        context = torch.sum(attn_w.unsqueeze(-1) * out, dim=1)      # (B, 2H)

        logits = self.fc(context)  # (B, num_classes)
        return logits


# -------------------------------------------------------
# MFCC 시퀀스 추출
# -------------------------------------------------------

def extract_mfcc_sequence(wav_path):
    # sr=48000 으로 리샘플링 (훈련 때와 동일하게)
    y, sr = librosa.load(wav_path, sr=48000)
    mfcc = librosa.feature.mfcc(y=y, sr=sr, n_mfcc=40)  # (F, T)
    mfcc = mfcc.T  # (T, F)
    return torch.tensor(mfcc, dtype=torch.float32)


# -------------------------------------------------------
# 단일 음성 예측 (확률 출력 포함)
# -------------------------------------------------------

def predict_single(wav_path, model_path="emotion_gru.pth"):
    device = "cuda" if torch.cuda.is_available() else "cpu"
    print(f"[INFO] Device: {device}")

    # 감정 클래스 준비
    emotion_classes = EMOTION_CLASSES
    num_classes = len(emotion_classes)

    # 모델 준비
    model = AttentionGRU(num_classes=num_classes).to(device)

    # DP(DataParallel) 학습된 경우 module. prefix 제거
    state_dict = torch.load(model_path, map_location=device)
    new_state_dict = {k.replace("module.", ""): v for k, v in state_dict.items()}
    model.load_state_dict(new_state_dict)

    model.eval()

    # MFCC 추출
    mfcc_seq = extract_mfcc_sequence(wav_path)          # (T, F)
    length = torch.tensor([len(mfcc_seq)], dtype=torch.long).to(device)
    mfcc_seq = mfcc_seq.unsqueeze(0).to(device)         # (1, T, F)

    # 예측
    with torch.no_grad():
        logits = model(mfcc_seq, length)                # (1, num_classes)
        probs = torch.softmax(logits, dim=1).cpu().numpy()[0]
        # (NEW) 확률 안전 정규화
        probs = probs / probs.sum()
        
    # 가장 높은 확률 index
    pred_idx = probs.argmax()
    pred_emotion = emotion_classes[pred_idx]

    # ----------------------------
    # 확률 출력
    # ----------------------------
    print("\n========================")
    print(f"🎧 입력 음성: {wav_path}")
    print("📊 감정별 확률")
    print("========================")

    for emotion, p in zip(emotion_classes, probs):
        print(f"{emotion:>5} : {p*100:6.2f}%")

    print("\n========================")
    print(f"🎯 최종 예측 감정: {pred_emotion} ({probs[pred_idx]*100:.2f}%)")
    print("========================\n")

    return pred_emotion, probs


# -------------------------------------------------------
# 실행
# -------------------------------------------------------

if __name__ == "__main__":
    wav_path = "fight.wav"
    predict_single(wav_path)

