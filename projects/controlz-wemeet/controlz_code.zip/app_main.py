"""
app_main.py
- 로컬 실험/검증용 실행기
- 녹음 → pipeline 실행 → 결과 출력
- 서버와 무관
"""

from record import record_until_silence
from pipeline import run_pipeline


def main():
    print("=" * 60)
    print("🎙 녹음 시작 (말하고 멈추면 자동 종료)")
    print("=" * 60)

    # 1️⃣ 녹음 (record.py 사용)
    audio_path = record_until_silence()

    print(f"\n📁 녹음 파일 저장 위치: {audio_path}")
    print("=" * 60)

    # 2️⃣ 파이프라인 실행
    child_text, ai_text, output_audio, meta = run_pipeline(audio_path)

    # 3️⃣ 결과 출력
    print("\n🧒 아이 발화(STT)")
    print(child_text)

    print("\n🤖 AI 응답(LLM)")
    print(ai_text)

    print("\n🔊 생성된 음성(TTS)")
    print(output_audio)

    print("\n⏱ 메타데이터")
    for k, v in meta.items():
        print(f"- {k}: {v}")

    print("=" * 60)
    print("✅ 파이프라인 실행 완료")


if __name__ == "__main__":
    main()
