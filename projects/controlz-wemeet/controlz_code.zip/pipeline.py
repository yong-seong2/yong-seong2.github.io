"""
pipeline.py
STT → LLM → TTS 를 하나로 묶은 '유일한' 파이프라인
- server/main.py
- app_main.py
둘 다 이 파일만 import해서 사용한다
"""

from pathlib import Path
import uuid
from .STT_test import stt
from .LLM_time import generate_reply
from .TTS_time import tts



# =========================
# 기본 설정
# =========================
BASE_DIR = Path(__file__).resolve().parent
OUTPUT_DIR = BASE_DIR / "outputs"
OUTPUT_DIR.mkdir(exist_ok=True)

VOICE_FILE_PATH = BASE_DIR / "캐릭터_샘플.wav"  # 네가 쓰는 캐릭터 음성


def run_pipeline(audio_path: str):
    """
    입력 음성 파일 경로를 받아
    STT → LLM → TTS 수행 후 결과 반환

    Returns
    -------
    child_text : str
    ai_text    : str
    output_audio_path : str
    metadata   : dict (latency, model_name 등)
    """

    audio_path = str(audio_path)
    uid = str(uuid.uuid4())

    # =========================
    # 1️⃣ STT
    # =========================
    child_text = stt(audio_path)

    # =========================
    # 2️⃣ LLM
    # =========================
    ai_text, latency, model_name = generate_reply(child_text)

    # =========================
    # 3️⃣ TTS
    # =========================
    output_audio_path = OUTPUT_DIR / f"{uid}_reply.wav"

    tts(
        text=ai_text,
        voice_file_path=str(VOICE_FILE_PATH),
        output_path=str(output_audio_path),
    )
    
    metadata = {
        "latency": latency,
        "model_name": model_name,
    }

    return child_text, ai_text, str(output_audio_path), metadata
