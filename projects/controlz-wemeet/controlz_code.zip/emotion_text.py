import os
from typing import List, Dict, Any
import numpy as np
import torch
from transformers import AutoTokenizer, AutoModelForSequenceClassification, pipeline

# -----------------------------
# 환경 설정
# -----------------------------
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"

HF_CACHE = "tmp/hf_cache"
os.environ["TRANSFORMERS_CACHE"] = HF_CACHE
os.makedirs(HF_CACHE, exist_ok=True)

EMO_MODEL_NAME = "dlckdfuf141/korean-emotion-kluebert-v2"

print(f"[LOAD] Loading emotion model: {EMO_MODEL_NAME}")

# -----------------------------
# 모델 라벨(id) → 7감정 매핑
# -----------------------------
ORIGINAL_LABELS = {
    0: "공포",
    1: "놀람",
    2: "분노",
    3: "슬픔",
    4: "중립",
    5: "행복",
    6: "혐오",
}

# -----------------------------
# 7감정 → 최종 5감정 재매핑
# -----------------------------
EMOTION_REMAP = {
    5: "기쁨",    # 행복 → 기쁨
    4: "없음",    # 중립 → 없음
    1: "없음",    # 놀람 → 없음
    2: "화남",    # 분노 → 화남
    6: "화남",    # 혐오 → 화남
    3: "슬픔",    # 슬픔 → 슬픔
    0: "두려움",  # 공포 → 두려움
}

FINAL_EMO_ID = {
    "기쁨": 0,
    "없음": 1,
    "화남": 2,
    "슬픔": 3,
    "두려움": 4,
}

# -----------------------------
# 토크나이저 & 모델 로드
# -----------------------------
tokenizer = AutoTokenizer.from_pretrained(EMO_MODEL_NAME)
emo_model = AutoModelForSequenceClassification.from_pretrained(EMO_MODEL_NAME)

if DEVICE == "cuda":
    emo_model = emo_model.to(DEVICE)

emotion_pipe = pipeline(
    task="text-classification",
    model=emo_model,
    tokenizer=tokenizer,
    device=0 if DEVICE == "cuda" else -1,
    return_all_scores=True,
)

print("[MODEL] Emotion pipeline loaded.")


# -----------------------------
# 단일 문장 감정 분석
# -----------------------------
def soften_probs(p, T=2.0):
    p = np.array(p, dtype=float)
    p = p ** (1.0 / T)     # 1/T 제곱
    p = p / p.sum()        # 정규화
    return p

def analyze_emotion(text: str) -> Dict[str, Any]:
    if not text or text.strip() == "":
        return {
            "text": text,
            "top_label": None,
            "top_label_id": None,
            "top_score": None,
            "scores": {},
        }

    outputs = emotion_pipe(text)
    scores_list = outputs[0]

    score_dict: Dict[str, float] = {}

    # 7 → 5 감정 재매핑
    for item in scores_list:
        raw_label = item["label"]
        label_id = int(raw_label) if isinstance(raw_label, str) else raw_label

        final_label = EMOTION_REMAP[label_id]  # 5개 감정으로 변환
        score = float(item["score"])

        # 여러 모델 라벨이 같은 최종 라벨로 매핑될 수 있으므로 합산
        score_dict[final_label] = score_dict.get(final_label, 0.0) + score

    # -------------------------------------
    # (NEW) score_dict → softening 적용
    # -------------------------------------
    labels_ordered = list(score_dict.keys())
    raw_probs = np.array([score_dict[k] for k in labels_ordered], dtype=float)
    soft_probs = soften_probs(raw_probs, T=2.0)

    # softening 결과를 다시 dict로 변환
    softened_scores = {
        label: float(prob) for label, prob in zip(labels_ordered, soft_probs)
    }

    # softening 이후 top label 재선정
    top_label_name = labels_ordered[int(np.argmax(soft_probs))]
    top_score = float(np.max(soft_probs))
    top_label_id = FINAL_EMO_ID[top_label_name]

    return {
        "text": text,
        "top_label": top_label_name,
        "top_label_id": top_label_id,
        "top_score": top_score,
        "scores": softened_scores,
    }



# -----------------------------
# 여러 문장 배치 분석
# -----------------------------
def analyze_emotion_batch(texts: List[str]) -> List[Dict[str, Any]]:
    if not texts:
        return []

    outputs = emotion_pipe(texts)
    results = []

    for text, scores_list in zip(texts, outputs):
        score_dict: Dict[str, float] = {}

        for item in scores_list:
            raw_label = item["label"]
            label_id = int(raw_label) if isinstance(raw_label, str) else raw_label

            final_label = EMOTION_REMAP[label_id]
            score = float(item["score"])

            score_dict[final_label] = score_dict.get(final_label, 0.0) + score

        top_label_name, top_score = max(score_dict.items(), key=lambda x: x[1])
        top_label_id = FINAL_EMO_ID[top_label_name]

        results.append(
            {
                "text": text,
                "top_label": top_label_name,
                "top_label_id": top_label_id,
                "top_score": top_score,
                "scores": score_dict,
            }
        )

    return results


# -----------------------------
# 테스트 코드
# -----------------------------
if __name__ == "__main__":
    sample_texts = [
        "오늘 기분이 너무 좋아! 진짜 행복해.",
        "솔직히 좀 불안하고 걱정돼.",
        "화가 나서 참을 수가 없어.",
        "그냥 아무 생각도 안 들고 평온한 느낌이야.",
        "괜찮다고 말은 하는데 솔직히 잘 모르겠어.",
        "별일은 없는데 기분이 좀 묘해.",
        "그냥 그런 날이야. 나쁘지도 좋지도 않아.",
        "웃고는 있는데 속은 타들어가는 느낌이야.",
        "다 잘 될 거라고 믿고 싶긴 해.",
    ]

    results = analyze_emotion_batch(sample_texts)

    for res in results:
        print("\n[TEXT]", res["text"])
        print("  → top_label:", res["top_label"])
        print("  → top_label_id:", res["top_label_id"])
        print("  → top_score:", round(res["top_score"], 4))
        pretty_scores = {k: round(v, 4) for k, v in res["scores"].items()}
        print("  → scores:", pretty_scores)
