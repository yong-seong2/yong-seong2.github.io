# TTS_time.py

import os
import time
from pathlib import Path
import torch

#import torchaudio
import soundfile as sf # ✅ soundfile 추가



# ---------------------------------------------------------

# ✅ DGX/Blackwell 호환성 및 환경 설정

# ---------------------------------------------------------

os.environ["TRITON_PTXAS_PATH"] = "/usr/local/cuda/bin/ptxas"
os.environ["TORCH_CUDA_ARCH_LIST"] = "9.0"

BASE_DIR = Path(__file__).resolve().parent

os.environ["TORCHINDUCTOR_CACHE_DIR"] = str(BASE_DIR / "tmp" / "torchinductor")

os.environ["XDG_CACHE_HOME"] = str(BASE_DIR / "tmp" / "huggingface_cache")

os.environ["TMPDIR"] = str(BASE_DIR / "tmp")



import torch._dynamo
torch._dynamo.config.suppress_errors = True
from zonos.model import Zonos
from zonos.conditioning import make_cond_dict



# -----------------------------

# ✅ TTS 는 GPU0 사용

# -----------------------------

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

print("[TTS] Loading Zonos model...")

try:

    model = Zonos.from_pretrained("Zyphra/Zonos-v0.1-transformer", device=device)

    model = model.to(device)

except Exception as e:

    print(f"[TTS] ⚠️ Model Load Warning: {e}")



if device.type == "cuda":

    print(f"[TTS] ✅ ready on {torch.cuda.get_device_name(0)}")

else:

    print("[TTS] ✅ ready on CPU")

# -----------------------------

# ✅ 오디오 로딩 함수 (soundfile로 교체)

# -----------------------------

def load_audio_with_codec(file_path):

    # torchaudio.load 대신 soundfile 사용

    try:

        wav_np, sr = sf.read(file_path, dtype='float32')

        wav = torch.from_numpy(wav_np)

       

        # (Time,) -> (1, Time) 또는 (Time, Channels) -> (Channels, Time) 변환

        if wav.ndim == 1:

            wav = wav.unsqueeze(0)

        else:

            wav = wav.t()

        if wav.shape[0] > 1:

            wav = wav.mean(dim=0, keepdim=True)

           
        return wav.to(device), sr

    except Exception as e:

        print(f"[TTS Error] 오디오 로딩 실패: {e}")

        return None, None



def format_time(ms):

    seconds = ms / 1000

    m = int(seconds // 60)

    s = seconds % 60

    return f"{m}분 {s:.2f}초"

# -----------------------------

def get_speaker_embedding(voice_file_path, embedding_path):

    embedding_path = Path(embedding_path)

    if embedding_path.exists():

        try:

            speaker = torch.load(embedding_path, map_location=device)

            print(f"[INFO] Loaded speaker embedding (캐시 사용) ← {embedding_path}")

            return speaker.to(device)

        except Exception:

            print("[INFO] 캐시된 임베딩 재생성 중...")



    wav, sr = load_audio_with_codec(voice_file_path)

    if wav is None:

        raise ValueError("화자 음성 파일을 불러올 수 없습니다.")



    speaker = model.make_speaker_embedding(wav, sr).to(device)


    embedding_path.parent.mkdir(parents=True, exist_ok=True)

    torch.save(speaker, embedding_path)

    print(f"[INFO] Created & Saved speaker embedding → {embedding_path}")


    return speaker.to(device)

# -----------------------------

def tts(text, voice_file_path, embedding_path=None, output_path="tts_output_zonos.wav"):

    """

    🎤 Zonos TTS (GPU) + 단계별 속도 출력

    """

    if embedding_path is None:

        embedding_path = "캐릭터_embedding.pt"

    # 1) Speaker Embedding

    t1 = time.time()

    speaker = get_speaker_embedding(voice_file_path, embedding_path)

    t_speaker = (time.time() - t1) * 1000

    # 2) Conditioning 생성

    t2 = time.time()

    cond_dict = make_cond_dict(text=text, speaker=speaker, language="ko")

    cond_dict = {

        k: (v.to(device) if torch.is_tensor(v) else v)

        for k, v in cond_dict.items()

    }

    conditioning = model.prepare_conditioning(cond_dict).to(device)

    t_condition = (time.time() - t2) * 1000

    # 3) 음성 코드 생성 (TTS 핵심)

    t3 = time.time()

    codes = model.generate(conditioning)

    t_generate = (time.time() - t3) * 1000

    # 4) 오디오 디코딩

    t4 = time.time()

    wavs = model.autoencoder.decode(codes).cpu()

    t_decode = (time.time() - t4) * 1000


    # ✅ 저장 부분 수정 (torchaudio.save -> soundfile.write)

    # wavs[0] 형태: (Channels, Time) -> squeeze -> (Time,)

    audio_np = wavs[0].squeeze().detach().numpy()

    sr = model.autoencoder.sampling_rate


    sf.write(output_path, audio_np, sr)

    # torchaudio.save(output_path, wavs[0], sr, format="wav") # 삭제

    total = t_speaker + t_condition + t_generate + t_decode


    print("\n===== 🎤 TTS Process Time Breakdown =====")
    print(f"(1) 화자 임베딩 (Speaker Embedding):   {format_time(t_speaker)}")
    print(f"(2) 문장 Conditioning 생성:            {format_time(t_condition)}")
    print(f"(3) 음성 코드 생성 (Generate):         {format_time(t_generate)}   ← ⭐ 병목 지점")
    print(f"(4) 오디오 복원 (Decode):              {format_time(t_decode)}")
    print(f"✅ Total TTS 처리시간:                  {format_time(total)}")
    print("=========================================\n")

    return output_path