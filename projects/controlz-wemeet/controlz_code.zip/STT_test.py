# STT_time.py
import os
import time
from pathlib import Path

import torch
import soundfile as sf
import librosa
from transformers import WhisperProcessor, WhisperForConditionalGeneration
from transformers.modeling_outputs import BaseModelOutput

# -------------------------------------------------------------
# 0. 경로 & 디바이스 설정
# -------------------------------------------------------------
BASE_DIR = Path(__file__).resolve().parent
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")

MODEL_NAME = BASE_DIR / "large"
if not MODEL_NAME.exists():
    MODEL_NAME = "openai/whisper-large"

HF_CACHE = BASE_DIR / "tmp" / "hf_cache"
HF_CACHE.mkdir(parents=True, exist_ok=True)
os.environ["TRANSFORMERS_CACHE"] = str(HF_CACHE)

print(f"[STT] Whisper 모델 불러오는 중... ({MODEL_NAME})")
t_load = time.time()

processor = WhisperProcessor.from_pretrained(str(MODEL_NAME))
model = WhisperForConditionalGeneration.from_pretrained(str(MODEL_NAME)).to(DEVICE)

if DEVICE.type == "cuda":
    torch.cuda.synchronize()

print(f"[STT] 모델 로드 완료: {time.time() - t_load:.3f}초\n")

# -------------------------------------------------------------
# 1. 프리엠퍼시스 / 소음 정규화
# -------------------------------------------------------------
def preprocess_audio(waveform: torch.Tensor) -> torch.Tensor:
    """
    waveform: (1, time)
    """
    pre_emphasis = 0.97

    # shape 안전 보장
    if waveform.ndim != 2:
        raise ValueError(f"waveform shape 에러: {waveform.shape}, (1, time) 여야 함")

    # pre-emphasis 적용
    y = waveform
    y_shift = torch.cat((y[:, :1], y[:, 1:] - pre_emphasis * y[:, :-1]), dim=1)

    # 정규화
    max_v = y_shift.abs().max()
    if max_v > 0:
        y_shift = y_shift / max_v

    return y_shift


# -------------------------------------------------------------
# 2. STT 함수
# -------------------------------------------------------------
def stt(audio_path: str, lang: str = "ko") -> str:
    print(f"\n[STT] 🎙 음성 파일 처리 시작: {audio_path}")

    if DEVICE.type == "cuda":
        torch.cuda.synchronize()

    # ---------------------------------------------------------
    # (1) 오디오 로드
    # ---------------------------------------------------------
    t1 = time.time()

    try:
        raw_np, sr = sf.read(audio_path, dtype="float32")
    except Exception as e:
        print(f"[ERROR] 오디오 로드 실패: {e}")
        return ""

    # raw_np shape 확인
    # mono: (T,)
    # stereo: (T,2)
    raw_tensor = torch.from_numpy(raw_np)

    # --- 무조건 mono 변환 ---
    if raw_tensor.ndim == 2:
        # (T, C) → 각 채널 평균 → (T,)
        raw_tensor = raw_tensor.mean(dim=1)

    # shape: (1, time)
    raw_tensor = raw_tensor.unsqueeze(0)

    if DEVICE.type == "cuda":
        torch.cuda.synchronize()
    print(f"[1] 오디오 로드 & mono 변환: {time.time() - t1:.4f}초")

    # ---------------------------------------------------------
    # (2) 리샘플링 → librosa
    # ---------------------------------------------------------
    t2 = time.time()
    target_sr = 16000

    if sr != target_sr:
        # raw_tensor: (1, time)
        mono_np = raw_tensor.squeeze().numpy()  # (time,)
        resampled_np = librosa.resample(
            mono_np,
            orig_sr=sr,
            target_sr=target_sr
        )
        waveform = torch.tensor(resampled_np).unsqueeze(0)  # (1, new_time)
        sr = target_sr
    else:
        waveform = raw_tensor

    if DEVICE.type == "cuda":
        torch.cuda.synchronize()
    print(f"[2] 리샘플링(16kHz 변환): {time.time() - t2:.4f}초")

    # ---------------------------------------------------------
    # (3) 소음 억제 / 프리엠퍼시스
    # ---------------------------------------------------------
    t3 = time.time()
    waveform = preprocess_audio(waveform)
    if DEVICE.type == "cuda":
        torch.cuda.synchronize()
    print(f"[3] 소음 억제(pre-emphasis): {time.time() - t3:.4f}초")

    # ---------------------------------------------------------
    # (4) Whisper Processor → Mel-spectrogram
    # ---------------------------------------------------------
    t4 = time.time()
    input_features = processor(
        waveform.squeeze(),                # float tensor (time,)
        sampling_rate=sr,
        return_tensors="pt"
    ).input_features.to(DEVICE)

    if DEVICE.type == "cuda":
        torch.cuda.synchronize()
    print(f"[4] Mel-spectrogram 추출: {time.time() - t4:.4f}초")

    # ---------------------------------------------------------
    # (5) Whisper 인코더
    # ---------------------------------------------------------
    t5 = time.time()
    encoder_out = model.model.encoder(input_features)
    if DEVICE.type == "cuda":
        torch.cuda.synchronize()
    print(f"[5] 인코더 처리: {time.time() - t5:.4f}초")

    # ---------------------------------------------------------
    # (6) 디코더 + 텍스트 생성
    # ---------------------------------------------------------
    t6 = time.time()
    encoder_outputs = BaseModelOutput(last_hidden_state=encoder_out.last_hidden_state)

    predicted_ids = model.generate(
        encoder_outputs=encoder_outputs
    )

    if DEVICE.type == "cuda":
        torch.cuda.synchronize()
    print(f"[6] 디코더 텍스트 생성: {time.time() - t6:.4f}초")

    # ---------------------------------------------------------
    # (7) Token → 문자열
    # ---------------------------------------------------------
    t7 = time.time()
    text = processor.batch_decode(predicted_ids, skip_special_tokens=True)[0]

    print(f"[7] 텍스트 변환: {time.time() - t7:.4f}초")

    print("\n-----------------------------------------------------")
    print(f"[STT] 전체 처리 시간: {time.time() - t1:.4f}초")
    print("-----------------------------------------------------\n")

    return text.strip()
