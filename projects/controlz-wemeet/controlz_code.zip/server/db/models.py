# server/db/models.py
from __future__ import annotations

from datetime import datetime, date
from sqlalchemy import (
    Column,
    Integer,
    String,
    DateTime,
    ForeignKey,
    Text,
    JSON,
    Date,
    Boolean,
)
from sqlalchemy.orm import relationship

from server.db.database import Base


# =========================
# 👤 Parent User (부모 계정)
# - 로그인은 항상 이 테이블로만
# =========================
class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)

    email = Column(String(255), unique=True, index=True, nullable=False)
    hashed_password = Column(String(255), nullable=False)

    # 이 부모 계정이 관리하는 아이(1명 가정)
    child_id = Column(Integer, ForeignKey("children.id"), nullable=False)

    created_at = Column(DateTime, default=datetime.utcnow)

    child = relationship("Child", back_populates="parent", uselist=False)
    sessions = relationship(
        "ConversationSession",
        back_populates="user",
        cascade="all, delete-orphan",
    )


# =========================
# 👧 Child (아이 프로필)
# =========================
class Child(Base):
    __tablename__ = "children"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), nullable=False)
    birth = Column(String(20), nullable=True)  # "2020-01-01" 문자열로 저장(간단)

    created_at = Column(DateTime, default=datetime.utcnow)

    parent = relationship("User", back_populates="child", uselist=False)
    todos = relationship(
        "Todo",
        back_populates="child",
        cascade="all, delete-orphan",
    )


# =========================
# ✅ Todo (숙제/일정)
# =========================
class Todo(Base):
    __tablename__ = "todos"

    id = Column(Integer, primary_key=True, index=True)
    child_id = Column(Integer, ForeignKey("children.id"), index=True, nullable=False)

    title = Column(String(255), nullable=False)
    time = Column(String(20), nullable=True)  # "14:00"
    date = Column(Date, nullable=False)

    is_completed = Column(Boolean, default=False)

    created_at = Column(DateTime, default=datetime.utcnow)

    child = relationship("Child", back_populates="todos")


# =========================
# 🗂 대화 세션
# =========================
class ConversationSession(Base):
    __tablename__ = "conversation_sessions"

    id = Column(Integer, primary_key=True, index=True)

    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)

    user = relationship("User", back_populates="sessions")
    turns = relationship(
        "ConversationTurn",
        back_populates="session",
        cascade="all, delete-orphan",
        order_by="ConversationTurn.created_at",
    )


# =========================
# 💬 대화 턴
# =========================
class ConversationTurn(Base):
    __tablename__ = "conversation_turns"

    id = Column(Integer, primary_key=True, index=True)

    session_id = Column(
        Integer,
        ForeignKey("conversation_sessions.id", ondelete="CASCADE"),
        nullable=False,
    )

    child_text = Column(Text, nullable=False)
    ai_text = Column(Text, nullable=False)

    audio_input_path = Column(String(500), nullable=False)
    audio_output_path = Column(String(500), nullable=False)

    pipeline_meta = Column(JSON, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    session = relationship("ConversationSession", back_populates="turns")
