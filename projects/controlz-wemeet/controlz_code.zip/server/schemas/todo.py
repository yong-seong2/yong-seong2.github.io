from pydantic import BaseModel
from datetime import date
from typing import Optional


class TodoCreate(BaseModel):
    title: str
    time: Optional[str] = None
    date: date


class TodoOut(BaseModel):
    id: int
    childId: int
    title: str
    time: Optional[str]
    date: date
    isCompleted: bool
