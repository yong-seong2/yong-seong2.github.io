# server/main.py
from __future__ import annotations

from fastapi import FastAPI, UploadFile, File, HTTPException, Depends
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from pathlib import Path
import shutil
import uuid

from sqlalchemy.orm import Session

from server.db.database import engine, get_db, Base
from server.api.auth import router as auth_router
from server.api.conversations import router as conversation_router
from server.api.todos import router as todos_router

from server.db.models import ConversationSession, ConversationTurn

# =========================
# (옵션) 모델 파이프라인
# =========================
RUN_PIPELINE_AVAILABLE = True
try:
    from model.pipeline import run_pipeline  # type: ignore
except Exception:
    RUN_PIPELINE_AVAILABLE = False
    run_pipeline = None  # type: ignore

# =========================
# (옵션) 오디오 유틸
# =========================
try:
    from server.utils.audio import ensure_wav  # type: ignore
except Exception:
    ensure_wav = None  # type: ignore


# =========================
# FastAPI App
# =========================
app = FastAPI(title="ControlZ Backend (No-Auth Mode)")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# =========================
# Upload 디렉토리
'''
BASE_DIR = Path(__file__).resolve().parent
UPLOAD_DIR = BASE_DIR / "uploads"
TTS_OUTPUTS_DIR = BASE_DIR / "model" / "outputs"

UPLOAD_DIR.mkdir(exist_ok=True)
app.mount("/uploads", StaticFiles(directory=UPLOAD_DIR), name="uploads")
# ✅ TTS 전용 경로 (새로 추가)
app.mount(
    "/tts",
    StaticFiles(directory=str(TTS_OUTPUTS_DIR)),
    name="tts"
)
'''

# 👉 controlz/ 디렉토리
PROJECT_ROOT = Path(__file__).resolve().parent.parent

# 기존 업로드 디렉토리 (절대 손상 안 됨)
UPLOAD_DIR = PROJECT_ROOT / "uploads"

# TTS 결과 디렉토리
TTS_OUTPUTS_DIR = PROJECT_ROOT / "model" / "outputs"

# 혹시 없으면 생성 (안전)
UPLOAD_DIR.mkdir(exist_ok=True)
TTS_OUTPUTS_DIR.mkdir(exist_ok=True)

# 기존 uploads 그대로 유지
app.mount(
    "/uploads",
    StaticFiles(directory=str(UPLOAD_DIR)),
    name="uploads"
)

# ✅ TTS 전용 static 경로 (새로 추가)
app.mount(
    "/tts",
    StaticFiles(directory=str(TTS_OUTPUTS_DIR)),
    name="tts"
)

# =========================
# DB 테이블 생성
# =========================
Base.metadata.create_all(bind=engine)

# =========================
# Router 등록
# =========================
app.include_router(auth_router)
app.include_router(conversation_router)
app.include_router(todos_router)


# =========================
# Health Check
# =========================
@app.get("/health")
def health():
    return {
        "status": "ok",
        "pipeline": "available" if RUN_PIPELINE_AVAILABLE else "disabled",
    }


# =========================
# 🎙 Audio Pipeline (🔥 인증 완전 제거)
# =========================
@app.post("/audio")
async def audio_pipeline(
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
):
    """
    ✅ 로그인 / 유저 개념 완전 제거
    ✅ 항상 user_id = 1 로 저장 (학습/시연용)
    """

    if not RUN_PIPELINE_AVAILABLE or run_pipeline is None:
        raise HTTPException(
            status_code=503,
            detail="AI pipeline is not available on this server.",
        )

    if ensure_wav is None:
        raise HTTPException(
            status_code=503,
            detail="Audio utility (ensure_wav) is missing.",
        )

    if not file.filename:
        raise HTTPException(status_code=400, detail="No file uploaded")

    # 🔥 고정 유저 ID
    TEST_USER_ID = 1

    uid = str(uuid.uuid4())
    suffix = Path(file.filename).suffix or ".m4a"
    input_audio_path = UPLOAD_DIR / f"{uid}_input{suffix}"

    with open(input_audio_path, "wb") as f:
        shutil.copyfileobj(file.file, f)

    # wav 변환
    wav_path = ensure_wav(str(input_audio_path))

    # 모델 실행
    child_text, ai_text, output_audio_path, metadata = run_pipeline(wav_path)

    # 대화 세션
    session = (
        db.query(ConversationSession)
        .filter(ConversationSession.user_id == TEST_USER_ID)
        .order_by(ConversationSession.created_at.desc())
        .first()
    )

    if session is None:
        session = ConversationSession(user_id=TEST_USER_ID)
        db.add(session)
        db.commit()
        db.refresh(session)

    turn = ConversationTurn(
        session_id=session.id,
        child_text=child_text,
        ai_text=ai_text,
        audio_input_path=str(input_audio_path),
        audio_output_path=str(output_audio_path) if output_audio_path else "",
        pipeline_meta=metadata,
    )

    db.add(turn)
    db.commit()
    return {
        "user_text": child_text,
        "response_text": ai_text,
        "tts_path": (
            f"/tts/{Path(output_audio_path).name}"
            if output_audio_path
            else ""
        ),
        "metadata": metadata,
    }

'''
    return {
        "user_text": child_text,
        "response_text": ai_text,
        "tts_path": (
            f"/uploads/{Path(output_audio_path).name}"
            if output_audio_path
            else ""
        ),
        "metadata": metadata,
    }
'''

