# server/api/conversations.py
from __future__ import annotations

from fastapi import APIRouter, Depends, Query, HTTPException
from sqlalchemy.orm import Session
from datetime import datetime, timedelta

from server.db.database import get_db
from server.db.models import ConversationTurn

router = APIRouter(prefix="/api", tags=["conversation"])


@router.get("/conversation-turns")
def get_conversation_turns_by_date(
    date: str = Query(..., description="YYYY-MM-DD"),
    db: Session = Depends(get_db),
):
    try:
        start = datetime.strptime(date, "%Y-%m-%d")
    except ValueError:
        raise HTTPException(status_code=400, detail="date must be YYYY-MM-DD")

    end = start + timedelta(days=1)

    turns = (
        db.query(ConversationTurn)
        .filter(ConversationTurn.created_at >= start, ConversationTurn.created_at < end)
        .order_by(ConversationTurn.created_at.asc())
        .all()
    )

    return {
        "date": date,
        "count": len(turns),
        "conversations": [
            {
                "id": t.id,
                "session_id": t.session_id,
                "child_text": t.child_text,
                "ai_text": t.ai_text,
                "audio_input_path": t.audio_input_path,
                "audio_output_path": t.audio_output_path,
                "pipeline_meta": t.pipeline_meta,
                "created_at": t.created_at.isoformat(),
            }
            for t in turns
        ],
    }
