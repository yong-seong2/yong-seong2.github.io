# server/api/auth.py
from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, EmailStr
from sqlalchemy.orm import Session

from server.db.database import get_db
from server.db.models import User, Child
from server.core.security import hash_password, verify_password

router = APIRouter(prefix="/auth", tags=["auth"])


class SignupRequest(BaseModel):
    id: str
    password: str
    childName: str
    childBirth: str  # "2020-01-01"


class LoginRequest(BaseModel):
    email: EmailStr
    password: str


@router.post("/signup", status_code=status.HTTP_201_CREATED)
def signup(req: SignupRequest, db: Session = Depends(get_db)):
    # 부모 이메일 중복 체크
    if db.query(User).filter(User.email == req.email).first():
        raise HTTPException(status_code=400, detail="Email already exists")

    # 아이 생성
    child = Child(name=req.childName, birth=req.childBirth)
    db.add(child)
    db.commit()
    db.refresh(child)

    # 부모 생성 (아이 연결)
    user = User(
        email=req.id,
        hashed_password=hash_password(req.password),
        child_id=child.id,
    )
    db.add(user)
    db.commit()
    db.refresh(user)

    return {
        "message": "Signup successful",
        "user": {
            "id": user.id,
            "email": user.email,
            "childId": user.child_id,
        },
        "child": {
            "id": child.id,
            "name": child.name,
            "birth": child.birth,
        },
    }


@router.post("/login")
def login(req: LoginRequest, db: Session = Depends(get_db)):
    print("🟡 LOGIN TRY:", req.email)

    user = (
        db.query(User)
        .filter(User.email == req.email)
        .first()
    )

    print("🟢 FOUND USER:", user)

    if not user:
        raise HTTPException(status_code=401, detail="User not found")

    if not verify_password(req.password, user.hashed_password):
        raise HTTPException(status_code=401, detail="Wrong password")

    return {
        "id": user.id,
        "email": user.email,
        "childId": user.child_id,
    }

