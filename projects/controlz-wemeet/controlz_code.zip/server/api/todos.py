from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from datetime import date

from server.db.database import get_db
from server.db.models import Todo
from server.schemas.todo import TodoCreate, TodoOut

router = APIRouter(
    prefix="/child/todos",
    tags=["todos"],
)

FIXED_CHILD_ID = 1  # 🔥 테스트용 하드코딩

@router.get("/today", response_model=list[TodoOut])
def get_today_todos(db: Session = Depends(get_db)):
    today = date.today()

    todos = (
        db.query(Todo)
        .filter(
            Todo.child_id == FIXED_CHILD_ID,
            Todo.date == today,
        )
        .order_by(Todo.id.asc())
        .all()
    )

    return [
        TodoOut(
            id=t.id,
            childId=FIXED_CHILD_ID,
            title=t.title,
            time=t.time,
            date=t.date,
            isCompleted=t.is_completed,
        )
        for t in todos
    ]


@router.post("", response_model=TodoOut)
def create_todo(payload: TodoCreate, db: Session = Depends(get_db)):
    todo = Todo(
        child_id=FIXED_CHILD_ID,  # 🔥 무조건 1
        title=payload.title,
        time=payload.time,
        date=payload.date,
        is_completed=False,
    )

    db.add(todo)
    db.commit()
    db.refresh(todo)

    return TodoOut(
        id=todo.id,
        childId=FIXED_CHILD_ID,
        title=todo.title,
        time=todo.time,
        date=todo.date,
        isCompleted=todo.is_completed,
    )
