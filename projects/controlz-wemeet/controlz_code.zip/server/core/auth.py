# server/core/auth.py
from fastapi import Depends, HTTPException
from sqlalchemy.orm import Session

from server.db.database import get_db
from server.db.models import User


def get_user_by_id(
    user_id: int,
    db: Session = Depends(get_db),
) -> User:
    """
    학습용 인증 대체:
    - 토큰 없이 user_id를 직접 받아 DB 조회
    """
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=401, detail="User not found")
    return user
