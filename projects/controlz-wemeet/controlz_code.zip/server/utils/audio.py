from pathlib import Path
import subprocess

FFMPEG_PATH = "/home/controlz/miniconda3/envs/torch310/bin/ffmpeg"

def ensure_wav(input_path: str) -> str:
    input_path = Path(input_path)
    ext = input_path.suffix.lower()

    if ext == ".wav":
        return str(input_path)

    output_path = input_path.with_suffix(".wav")

    cmd = [
        FFMPEG_PATH,
        "-y",
        "-i", str(input_path),
        "-ac", "1",
        "-ar", "16000",
        str(output_path),
    ]

    subprocess.run(
        cmd,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        check=True,
    )

    return str(output_path)
