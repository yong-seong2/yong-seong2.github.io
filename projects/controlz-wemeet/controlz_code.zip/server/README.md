
# 모델 돌아가는 코드
app_main.py
    STT_test.py
    LLM_time.py
    TTS_sh.py

가상환경 : torch310

# FastAPI 서버 관리 코드
server_main.py